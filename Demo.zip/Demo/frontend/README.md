# Demo_Project_BNP

SmartHire Frontend

Frontend-only React/Vite implementation based on the supplied SmartHire specification.

## Run

```bash
npm install
npm run dev
```

Copy `.env.example` to `.env`.

`VITE_USE_MOCK=true` uses the supplied demo dataset. Set it to `false` to use the FastAPI API through the centralized service layer.

Demo accounts:
- admin1 / admin123
- candidate1 / cand123
- interviewer1 / int123

The UI does not implement AI scoring. It displays screening scores/decisions supplied by the backend and uses mock responses until those endpoints are available.
