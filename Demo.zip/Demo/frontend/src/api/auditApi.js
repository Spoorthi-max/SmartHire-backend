import api,{useMock}from'./axios';import{auditLogs}from'../mock/data';export const getAuditLogs=async()=>useMock()?auditLogs:(await api.get('/admin/audit-logs')).data;
